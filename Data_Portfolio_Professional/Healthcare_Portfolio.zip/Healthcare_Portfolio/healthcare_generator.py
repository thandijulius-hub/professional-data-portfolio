import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
fake = Faker()

patients = []
conditions_list = ['Hypertension', 'Diabetes Type 2', 'COPD', 'Asthma', 'Osteoarthritis', 'Depression', 'Anxiety']

for i in range(100):
    admit = fake.date_between(start_date='-2y', end_date='today')
    stay = random.randint(1, 21)
    cost = round(random.uniform(1000, 50000), 2)
    coverage = round(random.uniform(0.7, 0.95), 2)
    
    patients.append({
        'Patient_ID': f'PAT{i:05d}',
        'MRN': f'MRN{random.randint(100000,999999)}',
        'Age': random.randint(18, 95),
        'Gender': random.choice(['Male', 'Female']),
        'Blood_Type': random.choice(['A+', 'O+', 'B+', 'AB+']),
        'Primary_Diagnosis': random.choice(conditions_list),
        'Secondary_Diagnosis': random.choice(['None'] + conditions_list),
        'Admission_Date': admit,
        'Discharge_Date': admit + timedelta(days=stay),
        'Length_of_Stay': stay,
        'Treatment_Cost': cost,
        'Insurance_Provider': random.choice(['Aetna', 'UnitedHealth', 'Cigna', 'Blue Cross', 'Medicare']),
        'Insurance_Coverage': coverage,
        'Patient_Responsibility': round(cost * (1 - coverage), 2),
        'Readmission_30_Days': 'Yes' if random.random() > 0.85 else 'No',
        'Medications': random.randint(1, 8),
        'Lab_Tests': random.randint(3, 15),
        'ER_Visits_Past_Year': random.randint(0, 5),
        'Smoking_Status': random.choice(['Never', 'Former', 'Current']),
        'BMI': round(random.uniform(18.5, 45), 1),
        'Discharge_Disposition': random.choice(['Home', 'Rehab', 'SNF', 'Hospice'])
    })

df = pd.DataFrame(patients)
df.to_csv('healthcare_data.csv', index=False)
df.to_excel('healthcare_data.xlsx', index=False)
print("✅ Healthcare data saved: 100 patients")