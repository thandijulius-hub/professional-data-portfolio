import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
fake = Faker()

users = []
plans = ['Free', 'Basic', 'Pro', 'Enterprise']
features = ['Analytics', 'API Access', 'Priority Support', 'Custom Domain', 'Team Members', 'Export']

for i in range(120):
    signup = fake.date_between(start_date='-365d', end_date='today')
    days_active = (datetime.now().date() - signup).days
    plan = random.choice(plans)
    
    # Plan-based revenue
    revenue_map = {'Free': 0, 'Basic': 29, 'Pro': 99, 'Enterprise': 499}
    mrr = revenue_map[plan]
    
    # Churn logic
    churn_risk = random.uniform(0, 1)
    if plan == 'Free':
        churn_risk += 0.3
    if days_active < 30:
        churn_risk += 0.2
    
    users.append({
        'User_ID': f'USER{i:05d}',
        'Email': fake.email(),
        'Company': fake.company(),
        'Industry': random.choice(['Tech', 'Healthcare', 'Finance', 'Education', 'Retail']),
        'Country': fake.country(),
        'Signup_Date': signup,
        'Days_Active': days_active,
        'Plan': plan,
        'Monthly_Revenue': mrr,
        'Total_Revenue': mrr * (days_active / 30),
        'Active_Features': random.randint(1, len(features)),
        'Features_List': ', '.join(random.sample(features, random.randint(1, len(features)))),
        'Sessions_Last_30d': random.randint(0, 500),
        'Avg_Session_Minutes': round(random.uniform(2, 45), 1),
        'Support_Tickets': random.randint(0, 15),
        'NPS_Score': random.randint(-100, 100),
        'Churn_Risk': round(min(churn_risk, 0.99), 2),
        'Predicted_LTV': round(random.uniform(0, 10000), 2),
        'Last_Active': fake.date_between(start_date=signup, end_date='today'),
        'Team_Size': random.randint(1, 50) if plan in ['Pro', 'Enterprise'] else 1,
        'Integration_Count': random.randint(0, 10),
        'Data_Volume_GB': round(random.uniform(0.1, 1000), 1)
    })

df = pd.DataFrame(users)
df.to_csv('saas_data.csv', index=False)
df.to_excel('saas_data.xlsx', index=False)
print("✅ SaaS data saved: 120 users with churn predictions")