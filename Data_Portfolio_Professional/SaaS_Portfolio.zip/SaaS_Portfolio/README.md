# 📱 SaaS User Analytics Dataset
**120 Users | Churn Prediction | Revenue Analysis**

## 📈 Subscription Metrics
- **Plans**: Free, Basic ($29), Pro ($99), Enterprise ($499)
- **Monthly Recurring Revenue (MRR)**: $0 - $499 per user
- **Churn Risk Scores**: 0.01 - 0.99 probability
- **Predicted LTV**: Customer lifetime value estimates

## 👥 User Segmentation
- **Industries**: Tech, Healthcare, Finance, Education, Retail
- **Company Sizes**: 1-50 team members
- **Geographic**: 28 countries represented
- **Activity Levels**: 0-500 sessions monthly

## 🔍 Behavioral Tracking
1. **Engagement**: Session frequency and duration
2. **Feature Adoption**: Which features users actually use
3. **Support Interactions**: Ticket volume and response times
4. **Integration Usage**: Third-party app connections

## 📊 Churn Prediction Factors
- **High Risk Indicators**: Free plan, low feature usage, declining sessions
- **Retention Signals**: Pro/Enterprise plans, high engagement, multiple integrations
- **Warning Signs**: Increased support tickets, negative NPS scores
- **Positive Signals**: Growing team size, data volume increases

## 💰 Revenue Analytics
- **MRR Distribution**: Breakdown by plan type
- **LTV Calculations**: Projected lifetime value
- **Upgrade Probability**: Free→Paid conversion likelihood
- **Expansion Revenue**: Add-on feature revenue potential

## 📁 Files Included
- `saas_data.csv` - Raw user data
- `saas_data.xlsx` - Business intelligence workbook
- `saas_preview.html` - Growth dashboard

## 🎯 Business Applications
- **SaaS Companies**: Reduce churn, increase upgrades
- **Investors**: Due diligence on SaaS metrics
- **Consultants**: Growth strategy development
- **Product Teams**: Feature usage analysis
- **Marketing**: Customer segmentation

## 📈 Impact Potential
Typical results using this data:
- **Churn Reduction**: 15-25% decrease in 90 days
- **Upgrade Increase**: 20-30% more free→paid conversions
- **LTV Improvement**: 10-20% increase in customer value
- **Support Efficiency**: 30-40% reduction in ticket volume

---
*Compatible with Mixpanel, Amplitude, Google Analytics, and custom analytics platforms.*