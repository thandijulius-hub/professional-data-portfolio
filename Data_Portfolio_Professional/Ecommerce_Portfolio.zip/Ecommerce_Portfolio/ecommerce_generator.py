import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
fake = Faker()

# Generate data
products = []
for i in range(150):
    cost = round(random.uniform(10, 500), 2)
    price = round(cost * random.uniform(1.2, 2.5), 2)
    
    products.append({
        'Product_ID': f'PROD{i:04d}',
        'Product_Name': fake.catch_phrase(),
        'Category': random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports']),
        'Brand': fake.company(),
        'Supplier': fake.company(),
        'Cost': cost,
        'Price': price,
        'Margin': round(((price - cost) / price) * 100, 1),
        'Stock': random.randint(0, 1000),
        'SKU': f'SKU{random.randint(10000,99999)}',
        'Rating': round(random.uniform(1, 5), 1),
        'Reviews': random.randint(0, 5000),
        'Weight_kg': round(random.uniform(0.1, 20), 2),
        'Dimensions': f"{random.randint(10,100)}x{random.randint(10,100)}x{random.randint(5,50)}cm",
        'Last_Restock': fake.date_between(start_date='-180d', end_date='today'),
        'Discontinued': 'No'
    })

# Save files
df = pd.DataFrame(products)
df.to_csv('ecommerce_data.csv', index=False)
df.to_excel('ecommerce_data.xlsx', index=False)
print("✅ E-commerce data saved: 150 products")