import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
fake = Faker()

properties = []
cities = [
    ('New York', 'NY', 850000), ('Los Angeles', 'CA', 950000),
    ('Chicago', 'IL', 350000), ('Houston', 'TX', 320000),
    ('Phoenix', 'AZ', 420000), ('Miami', 'FL', 550000)
]

for i in range(80):
    city, state, avg = random.choice(cities)
    base_price = avg * random.uniform(0.7, 1.5)
    beds = random.randint(1, 5)
    sqft = beds * 600 + random.randint(-200, 400)
    
    properties.append({
        'Property_ID': f'RE{i:04d}',
        'Address': fake.street_address(),
        'City': city,
        'State': state,
        'Zip': fake.zipcode(),
        'Beds': beds,
        'Baths': beds - random.choice([0, 0, 1]),
        'SqFt': sqft,
        'Lot_Size': random.randint(2000, 10000) if beds > 2 else random.randint(800, 2500),
        'Year_Built': random.randint(1950, 2023),
        'Property_Type': random.choice(['Single Family', 'Condo', 'Townhouse']),
        'List_Price': int(base_price),
        'Price_per_SqFt': int(base_price / sqft),
        'Days_on_Market': random.randint(1, 180),
        'Status': random.choice(['Active', 'Pending', 'Sold']),
        'HOA_Fee': random.randint(0, 500) if random.random() > 0.5 else 0,
        'Tax_Rate': round(random.uniform(0.5, 2.5), 2),
        'Estimated_Rent': int(base_price * 0.005 * random.uniform(0.8, 1.2)),
        'Cap_Rate': round((base_price * 0.005 * 12 / base_price) * 100, 2),
        'School_Rating': random.randint(4, 10),
        'Walk_Score': random.randint(0, 100)
    })

df = pd.DataFrame(properties)
df.to_csv('realestate_data.csv', index=False)
df.to_excel('realestate_data.xlsx', index=False)
print("✅ Real estate data saved: 80 properties")