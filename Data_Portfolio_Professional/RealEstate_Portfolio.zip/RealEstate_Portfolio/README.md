# 🏠 Real Estate Investment Analysis Dataset
**80 Properties | Cap Rate Calculations | Market Intelligence**

## 📈 Investment Metrics
- **Cap Rates**: 3.8% - 8.2% range
- **Price per SqFt**: $150 - $950 across markets
- **Rental Yields**: Estimated monthly rents included
- **Tax Analysis**: Property tax rates by jurisdiction

## 🏙️ Geographic Coverage
6 major metro areas:
- New York, NY (High value, lower cap rates)
- Los Angeles, CA (Premium market)
- Chicago, IL (Value opportunities)
- Houston, TX (Growing market)
- Phoenix, AZ (Hot market)
- Miami, FL (Luxury segment)

## 🧮 Calculated Fields
1. **Cap Rate** = (Annual Rent / Price) × 100
2. **Price per SqFt** = List Price / Square Footage
3. **Cash Flow** = Rent - (Taxes + HOA + Maintenance)
4. **ROI Projection** = 5-year appreciation estimate

## 🎯 Target Users
- **Real Estate Investors**: Find undervalued properties
- **Agents**: Market analysis for clients
- **Lenders**: Risk assessment for