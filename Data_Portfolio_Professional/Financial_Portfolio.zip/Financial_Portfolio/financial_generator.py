import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
fake = Faker()

transactions = []
for i in range(200):
    amount = round(random.uniform(10, 10000), 2)
    hour = random.randint(0, 23)
    
    # Fraud logic
    is_fraud = False
    fraud_type = 'Legitimate'
    
    # 7% fraud rate
    if random.random() < 0.07:
        is_fraud = True
        amount = round(random.uniform(500, 10000), 2)  # Fraud tends higher
        fraud_type = random.choice(['Card Not Present', 'Account Takeover', 'Friendly Fraud', 'Merchant Collusion'])
    
    transactions.append({
        'Transaction_ID': f'TXN{i:06d}',
        'Customer_ID': f'CUST{random.randint(10000,99999)}',
        'Timestamp': fake.date_time_between(start_date='-30d', end_date='now'),
        'Amount': amount,
        'Currency': random.choice(['USD', 'EUR', 'GBP']),
        'Merchant': fake.company(),
        'Merchant_Category': random.choice(['Retail', 'Travel', 'Digital Goods', 'Gambling', 'Services']),
        'Country': fake.country_code(),
        'Transaction_Type': random.choice(['Online', 'In-Store', 'ATM']),
        'Card_Type': random.choice(['Credit', 'Debit']),
        'Hour_of_Day': hour,
        'Is_Weekend': 'Yes' if hour in [18, 19, 20, 21, 22] else 'No',
        'Is_Fraud': 'Yes' if is_fraud else 'No',
        'Fraud_Type': fraud_type,
        'Previous_Declines': random.randint(0, 3) if is_fraud else 0,
        'IP_Address': fake.ipv4(),
        'Device_ID': f'DEV{random.randint(1000000,9999999)}',
        'Browser': random.choice(['Chrome', 'Safari', 'Firefox', 'Edge']),
        'Shipping_Billing_Match': random.choice(['Yes', 'No']),
        'Transaction_Velocity': random.randint(1, 20)  # Transactions last hour
    })

df = pd.DataFrame(transactions)
df.to_csv('financial_data.csv', index=False)
df.to_excel('financial_data.xlsx', index=False)
print("✅ Financial data saved: 200 transactions (7% fraud rate)")