# 💳 Financial Fraud Detection Dataset
**200 Transactions | 7% Fraud Rate | Pattern Analysis**

## 🚨 Fraud Detection Features
- **Fraud Types**: Card Not Present, Account Takeover, Friendly Fraud, Merchant Collusion
- **Detection Signals**: Transaction velocity, time patterns, geographic flags
- **Risk Factors**: High-risk merchants, unusual hours, mismatched locations

## 📊 Transaction Analysis
1. **Amount Distribution**: $10 - $10,000 range
2. **Time Patterns**: 24-hour analysis with weekend flags
3. **Geographic Data**: Multi-country transaction origins
4. **Device Tracking**: Browser, IP, device IDs

## 🔍 Fraud Indicators Tracked
- **Transaction Velocity**: Multiple rapid transactions
- **Time Anomalies**: Unusual purchase hours
- **Geographic Impossibilities**: Rapid location changes
- **Merchant Risk**: High-risk category spending
- **Behavior Changes**: Deviation from customer patterns

## 🎯 Model Training Ready
**Perfect for machine learning models:**
- Binary classification (Fraud/Not Fraud)
- Multi-class classification (Fraud type)
- Anomaly detection algorithms
- Pattern recognition training

## 📈 Statistical Profile
- **Total Transactions**: 200
- **Fraud Rate**: 7% (industry average: 5-10%)
- **Average Fraud Amount**: $3,850
- **Average Legitimate Amount**: $845
- **High-Risk Hours**: 18:00-22:00
- **High-Risk Categories**: Gambling, Digital Goods

## 📁 Files Included
- `financial_data.csv` - Raw transaction data
- `financial_data.xlsx` - Analysis workbook
- `financial_preview.html` - Fraud dashboard

## 🛡️ Security Applications
- **Banks**: Real-time fraud detection systems
- **Payment Processors**: Rule engine optimization
- **E-commerce**: Transaction risk scoring
- **FinTech**: ML model development
- **Auditors**: Fraud pattern analysis

## 💰 Financial Impact
Typical ROI: For every $1 spent on fraud detection, clients save $5-10 in prevented losses. Early detection reduces fraud losses by 40-60%.

---
*PCI DSS compliant format. Ready for Splunk, Elasticsearch, or custom fraud systems.*